@echo off
cd /d "%~dp0"
if not exist build\web mkdir build\web
where godot >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  godot --headless --path . --export-release Web build/web/index.html
) else (
  echo Godot is not in PATH. Open project in Godot and select Project - Export - Web.
)
pause
