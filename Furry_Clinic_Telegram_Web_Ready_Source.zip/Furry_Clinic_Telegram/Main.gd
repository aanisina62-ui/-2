extends Control

var cases = []
var current_case = {}
var generated_cases_count = 0
var recent_case_signatures = []
var selected_methods = []
var diagnosis_options = []
var treatment_options = []
var selected_diagnosis = ""
var selected_treatment = ""
var current_result = "Выберите метод диагностики."
var stage = 1
var score = 0
var money = 500
var stars = 0
var streak = 0
var cases_done = 0
var case_finished = false
var day = 1
var day_patients = 0
var clinic_rating = 0.0
var day_correct = 0
var day_researches = 0
var diagnostic_flags = {"teeth_problem": false, "respiratory_problem": false, "skin_problem": false, "gi_problem": false, "infection": false}
const SAVE_PATH = "user://clinic_save.cfg"

var reference_db = {}
var ref_species_box
var ref_organs_box
var ref_diseases_box
var ref_card
var ref_card_title


const BG = Color("#0b141e")
const PANEL = Color("#162331")
const PANEL_2 = Color("#1b2b3a")
const CARD = Color("#223445")
const CARD_HOVER = Color("#29445a")
const LINE = Color("#344b60")
const TEXT = Color("#e9f1f7")
const MUTED = Color("#9fb0bf")
const BLUE = Color("#2da8ff")
const GREEN = Color("#37d67a")
const RED = Color("#ff6577")
const YELLOW = Color("#ffc857")

func _ready():
	_load_cases()
	_load_other_species()
	_show_main_menu()


var selected_animal_group = "Грызуны"
var cat_dog_reference = {}
var rodent_cases = []
var other_cases = []

func _show_main_menu():
	_clear_ui()
	var bg = ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var p = _panel(bg, Rect2(330, 100, 600, 480), PANEL, LINE, 16)
	_label(p, "Клиника пушистых животных", Rect2(30, 35, 540, 50), 27, TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	_label(p, "Выберите действие", Rect2(30, 100, 540, 30), 18, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	_button(p, "Продолжить", Rect2(100, 180, 400, 70), _start_menu_continue, true, true)
	_button(p, "Начать заново", Rect2(100, 275, 400, 70), _start_menu_new, true, false)

func _start_menu_continue():
	if not _load_save():
		_show_animal_selection()
		return
	if not current_case.is_empty() and not case_finished:
		cases = _cases_for_selected_group()
		_render()
	else:
		_show_animal_selection()

func _start_menu_new():
	_reset_progress()
	_save()
	_show_animal_selection()

func _reset_progress():
	money = 500
	stars = 0
	score = 0
	day = 1
	cases_done = 0
	day_patients = 0
	day_correct = 0
	day_researches = 0
	clinic_rating = 0.0
	streak = 0
	generated_cases_count = 0
	recent_case_signatures = []
	current_case = {}
	selected_methods = []
	selected_diagnosis = ""
	selected_treatment = ""
	current_result = "Выберите метод диагностики."
	stage = 1
	case_finished = false
	selected_animal_group = "Грызуны"
	diagnostic_flags = {"teeth_problem": false, "respiratory_problem": false, "skin_problem": false, "gi_problem": false, "infection": false}

func _show_animal_selection():
	_clear_ui()
	var bg = ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var p = _panel(bg, Rect2(330, 20, 600, 680), PANEL, LINE, 16)
	_label(p, "Выбор животного", Rect2(30, 28, 540, 46), 28, TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	_label(p, "Выберите группу пациентов", Rect2(30, 85, 540, 32), 17, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
	_button(p, "Кошки", Rect2(100, 140, 400, 72), _choose_animal_group.bind("Кошки"), true, true)
	_button(p, "Собаки", Rect2(100, 230, 400, 72), _choose_animal_group.bind("Собаки"), true, true)
	_button(p, "Грызуны", Rect2(100, 320, 400, 60), _choose_animal_group.bind("Грызуны"), true, true)
	_button(p, "Лошади", Rect2(100, 395, 400, 60), _choose_animal_group.bind("Лошади"), true, true)
	_button(p, "Коровы", Rect2(100, 470, 400, 60), _choose_animal_group.bind("Коровы"), true, true)
	_button(p, "Назад", Rect2(100, 585, 400, 60), _show_main_menu)

func _choose_animal_group(group):
	selected_animal_group = group
	_save()
	_show_group_disease_tree()

func _show_group_disease_tree():
	_clear_ui()
	var bg = ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var p = _panel(bg, Rect2(90, 30, 1100, 660), PANEL, LINE, 16)
	_label(p, "Древо болезней — " + selected_animal_group, Rect2(30, 20, 800, 42), 26, TEXT)
	_button(p, "Назад", Rect2(920, 20, 145, 44), _show_animal_selection)
	_button(p, "Открыть древо болезней", Rect2(180, 170, 740, 90), _open_group_reference, true, true)
	_button(p, "Перейти к осмотру", Rect2(180, 310, 740, 90), new_case, true, false)
	_label(p, "Справочник и осмотр соответствуют выбранной группе животных.", Rect2(120, 450, 860, 80), 18, MUTED, HORIZONTAL_ALIGNMENT_CENTER)

func _open_group_reference():
	if selected_animal_group == "Грызуны":
		_show_reference()
	else:
		_show_cat_dog_reference()

func _show_cat_dog_reference():
	var overlay = ColorRect.new()
	overlay.color = Color(0.02, 0.05, 0.08, 0.97)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(overlay)
	var p = _panel(overlay, Rect2(40, 20, 1200, 700), Color("#132130"), Color("#41657d"), 14)
	_label(p, "ДРЕВО БОЛЕЗНЕЙ — " + selected_animal_group.to_upper(), Rect2(25, 15, 890, 40), 24, TEXT)
	_button(p, "Закрыть", Rect2(1030, 15, 120, 42), overlay.queue_free)
	var left = _panel(p, Rect2(20, 70, 430, 600), Color("#182b3b"))
	var right = _panel(p, Rect2(470, 70, 700, 600), Color("#182b3b"))
	_label(left, "Системы органов и заболевания", Rect2(15, 10, 400, 35), 18, TEXT)
	_label(right, "Выберите заболевание слева", Rect2(20, 15, 650, 40), 20, TEXT)
	var scroll = _reference_scroll_content(left, "SpeciesTreeScroll")
	var y = 8
	var first_disease = ""
	var first_card = {}
	var group_data = cat_dog_reference.get(selected_animal_group, {})
	for organ in group_data.keys():
		_label(scroll, str(organ), Rect2(10, y, 360, 30), 18, GREEN)
		y += 35
		for disease in group_data[organ].keys():
			if first_disease == "":
				first_disease = str(disease)
				first_card = group_data[organ][disease]
			_button(scroll, str(disease), Rect2(10, y, 360, 40), _show_reference_card.bind(str(disease), group_data[organ][disease], right))
			y += 47
	scroll.custom_minimum_size.y = max(y + 20, 540)
	if first_disease != "":
		_show_reference_card(first_disease, first_card, right)
	else:
		_label(right, "Для этой группы заболевания пока не добавлены.", Rect2(20, 80, 630, 80), 17, MUTED)


func _open_reference_book():
	_open_group_reference()

func _new_game():
	_reset_progress()
	_save()
	new_case()

func _continue_game():
	if _load_save() and not current_case.is_empty() and not case_finished:
		_render()
	else:
		new_case()

func _load_save() -> bool:
	var cfg = ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return false
	day = int(cfg.get_value("clinic", "day", 1))
	clinic_rating = float(cfg.get_value("clinic", "rating", 0.0))
	money = int(cfg.get_value("clinic", "money", 500))
	stars = int(cfg.get_value("clinic", "stars", 0))
	score = int(cfg.get_value("clinic", "score", 0))
	cases_done = int(cfg.get_value("clinic", "cases_done", 0))
	day_patients = int(cfg.get_value("clinic", "day_patients", 0))
	day_correct = int(cfg.get_value("clinic", "day_correct", 0))
	day_researches = int(cfg.get_value("clinic", "day_researches", 0))
	streak = int(cfg.get_value("clinic", "streak", 0))
	generated_cases_count = int(cfg.get_value("clinic", "generated_cases_count", 0))
	selected_animal_group = str(cfg.get_value("clinic", "animal_group", "Грызуны"))
	current_case = cfg.get_value("patient", "current_case", {})
	selected_methods = cfg.get_value("patient", "selected_methods", [])
	selected_diagnosis = str(cfg.get_value("patient", "selected_diagnosis", ""))
	selected_treatment = str(cfg.get_value("patient", "selected_treatment", ""))
	current_result = str(cfg.get_value("patient", "current_result", "Выберите метод диагностики."))
	stage = int(cfg.get_value("patient", "stage", 1))
	case_finished = bool(cfg.get_value("patient", "case_finished", false))
	diagnostic_flags = cfg.get_value("patient", "diagnostic_flags", {"teeth_problem": false, "respiratory_problem": false, "skin_problem": false, "gi_problem": false, "infection": false})
	recent_case_signatures = cfg.get_value("patient", "recent_case_signatures", [])
	if not current_case.is_empty():
		diagnosis_options = [current_case.get("disease", "")]
		for d in current_case.get("distractors", []):
			diagnosis_options.append(d)
		treatment_options = current_case.get("treatments", []).duplicate()
	return true

func _save():
	var cfg = ConfigFile.new()
	cfg.set_value("clinic", "day", day)
	cfg.set_value("clinic", "rating", clinic_rating)
	cfg.set_value("clinic", "money", money)
	cfg.set_value("clinic", "stars", stars)
	cfg.set_value("clinic", "score", score)
	cfg.set_value("clinic", "cases_done", cases_done)
	cfg.set_value("clinic", "day_patients", day_patients)
	cfg.set_value("clinic", "day_correct", day_correct)
	cfg.set_value("clinic", "day_researches", day_researches)
	cfg.set_value("clinic", "streak", streak)
	cfg.set_value("clinic", "generated_cases_count", generated_cases_count)
	cfg.set_value("clinic", "animal_group", selected_animal_group)
	cfg.set_value("patient", "current_case", current_case)
	cfg.set_value("patient", "selected_methods", selected_methods)
	cfg.set_value("patient", "selected_diagnosis", selected_diagnosis)
	cfg.set_value("patient", "selected_treatment", selected_treatment)
	cfg.set_value("patient", "current_result", current_result)
	cfg.set_value("patient", "stage", stage)
	cfg.set_value("patient", "case_finished", case_finished)
	cfg.set_value("patient", "diagnostic_flags", diagnostic_flags)
	cfg.set_value("patient", "recent_case_signatures", recent_case_signatures)
	var err = cfg.save(SAVE_PATH)
	if err != OK:
		push_error("Не удалось сохранить игру: %s" % error_string(err))

func _notification(what):
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		_save()

func _finish_day():
	if day_patients >= 5:
		day += 1
		day_patients = 0
		day_correct = 0
		day_researches = 0
		_save()
		current_result = "Начался день %d. Новые 5 пациентов." % day

func _load_cases():
	var f = FileAccess.open("res://data/rodent_cases.json", FileAccess.READ)
	if f == null:
		push_error("Не удалось открыть data/rodent_cases.json")
		return
	var parsed = JSON.parse_string(f.get_as_text())
	if typeof(parsed) == TYPE_ARRAY:
		cases = parsed
	else:
		push_error("Ошибка JSON: rodent_cases.json")

func _load_other_species():
	rodent_cases = cases.duplicate(true)
	var file = FileAccess.open("res://data/cat_dog_cases.json", FileAccess.READ)
	if file:
		var parsed = JSON.parse_string(file.get_as_text())
		if typeof(parsed) == TYPE_DICTIONARY:
			other_cases = parsed.get("cases", [])
			cat_dog_reference = parsed.get("reference", {})

func _cases_for_selected_group():
	if selected_animal_group == "Грызуны":
		return rodent_cases
	var result = []
	var species_by_group = {"Кошки": "Кошка", "Собаки": "Собака", "Лошади": "Лошадь", "Коровы": "Корова"}
	var species_name = species_by_group.get(selected_animal_group, "")
	for item in other_cases:
		if item.get("species", "") == species_name:
			result.append(item)
	return result

func _clear_ui():
	for child in get_children():
		remove_child(child)
		child.queue_free()

func _stylebox(color, border_color = LINE, radius = 12, border_width = 1):
	var s = StyleBoxFlat.new()
	s.bg_color = color
	s.border_color = border_color
	s.border_width_left = border_width
	s.border_width_top = border_width
	s.border_width_right = border_width
	s.border_width_bottom = border_width
	s.corner_radius_top_left = radius
	s.corner_radius_top_right = radius
	s.corner_radius_bottom_left = radius
	s.corner_radius_bottom_right = radius
	return s

func _panel(parent, rect, color = PANEL, border_color = LINE, radius = 12):
	var p = Panel.new()
	p.position = rect.position
	p.size = rect.size
	p.add_theme_stylebox_override("panel", _stylebox(color, border_color, radius, 1))
	parent.add_child(p)
	return p

func _label(parent, text_value, rect, font_size = 16, color = TEXT, align = HORIZONTAL_ALIGNMENT_LEFT):
	var l = Label.new()
	l.text = text_value
	l.position = rect.position
	l.size = rect.size
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	l.horizontal_alignment = align
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)
	return l

func _flow_label(parent, text_value, font_size = 14, color = TEXT, min_height = 24, align = HORIZONTAL_ALIGNMENT_LEFT):
	var l = Label.new()
	l.text = text_value
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	l.horizontal_alignment = align
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	l.custom_minimum_size = Vector2(0, min_height)
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_color_override("font_color", color)
	parent.add_child(l)
	return l

func _button(parent, text_value, rect, callback, enabled = true, accent = false):
	var b = Button.new()
	b.text = text_value
	b.position = rect.position
	b.size = rect.size
	b.disabled = not enabled
	b.clip_text = false
	b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	b.add_theme_font_size_override("font_size", 14)
	var normal_color = BLUE.darkened(0.55) if accent else CARD
	var hover_color = BLUE.darkened(0.35) if accent else CARD_HOVER
	var border_color = BLUE if accent else LINE
	b.add_theme_stylebox_override("normal", _stylebox(normal_color, border_color, 8, 1))
	b.add_theme_stylebox_override("hover", _stylebox(hover_color, BLUE, 8, 1))
	b.add_theme_stylebox_override("pressed", _stylebox(BLUE.darkened(0.25), BLUE, 8, 1))
	b.add_theme_stylebox_override("disabled", _stylebox(Color("#18222c"), Color("#263645"), 8, 1))
	b.add_theme_color_override("font_color", TEXT)
	b.add_theme_color_override("font_disabled_color", Color("#627383"))
	b.pressed.connect(func():
		if callback is Callable:
			callback.call()
	)
	parent.add_child(b)
	return b

func _rich(parent, rect):
	var r = RichTextLabel.new()
	r.position = rect.position
	r.size = rect.size
	r.bbcode_enabled = true
	r.fit_content = false
	r.scroll_active = true
	r.add_theme_font_size_override("normal_font_size", 15)
	r.add_theme_color_override("default_color", TEXT)
	parent.add_child(r)
	return r

func new_case():
	cases = _cases_for_selected_group()
	if cases.size() == 0:
		return
	current_case = _generate_case()
	generated_cases_count += 1
	selected_methods = []
	selected_diagnosis = ""
	selected_treatment = ""
	current_result = "Выберите метод диагностики. Для постановки диагноза выполните минимум 2 исследования."
	stage = 1
	case_finished = false
	diagnosis_options = [current_case["disease"]]
	for d in current_case["distractors"]:
		diagnosis_options.append(d)
	diagnosis_options.shuffle()
	treatment_options = current_case["treatments"].duplicate()
	treatment_options.shuffle()
	_save()
	_render()


func _canonical_species(species_name):
	var aliases = {
		"Морская свинка": "Морские свинки",
		"Кролик": "Кролики",
		"Крыса": "Крысы и мыши",
		"Мышь": "Крысы и мыши",
		"Хомяк": "Хомяки",
		"Шиншилла": "Шиншиллы"
	}
	return aliases.get(str(species_name), str(species_name))

func _random_name_for_species(species_name):
	var pools = {
		"Кролики": ["Снежок", "Луна", "Плюш", "Ириска", "Тоша", "Буся", "Персик", "Мия"],
		"Морские свинки": ["Плюша", "Кнопа", "Фрося", "Пончик", "Чип", "Лола", "Боня", "Пеппа"],
		"Крысы и мыши": ["Реми", "Пиксель", "Нора", "Честер", "Мышка", "Локи", "Тучка", "Байт"],
		"Хомяки": ["Хома", "Пуфик", "Крош", "Соня", "Бублик", "Тоффи", "Пышка", "Жужа"],
		"Хорьки": ["Феня", "Марс", "Рокки", "Лиса", "Ника", "Тэдди", "Сима", "Фокс"],
		"Шиншиллы": ["Дымка", "Шуша", "Сильвер", "Мята", "Пепел", "Лея", "Туман", "Чилли"],
		"Кошка": ["Мурка", "Луна", "Барсик", "Мия", "Персик"],
		"Собака": ["Рекс", "Боня", "Лаки", "Джесси", "Тайсон"],
		"Лошадь": ["Звезда", "Буран", "Гроза", "Искра", "Ветер"],
		"Корова": ["Зорька", "Бурёнка", "Марта", "Ромашка", "Ночка"]
	}
	var pool = pools.get(species_name, ["Пациент"])
	return str(pool[randi() % pool.size()])

func _random_age_for_species(species_name):
	var ranges = {
		"Кролики": [4, 96],
		"Морские свинки": [3, 84],
		"Крысы и мыши": [2, 36],
		"Хомяки": [2, 30],
		"Хорьки": [4, 108],
		"Шиншиллы": [6, 180],
		"Кошка": [6, 180],
		"Собака": [6, 180],
		"Лошадь": [12, 300],
		"Корова": [12, 180]
	}
	var r = ranges.get(species_name, [3, 60])
	var months = randi_range(int(r[0]), int(r[1]))
	if months < 12:
		return "%d мес." % months
	var years = float(months) / 12.0
	return "%.1f года" % years

func _severity_prefix(severity):
	if severity == "лёгкая":
		return "Симптомы появились недавно. "
	if severity == "тяжёлая":
		return "Состояние заметно ухудшилось. "
	return "Симптомы сохраняются несколько дней. "

func _extra_symptoms_for_disease(disease_name):
	var d = str(disease_name).to_lower()
	if "пневмон" in d or "ринит" in d or "дыхатель" in d or "микоплаз" in d or "грипп" in d:
		return ["быстро устаёт", "стал меньше двигаться", "периодически чихает", "хуже ест обычный корм"]
	if "зуб" in d or "малокклю" in d or "резц" in d:
		return ["дольше пережёвывает корм", "выбирает мягкую пищу", "роняет кусочки корма", "стал терять массу"]
	if "энтер" in d or "жкт" in d or "гастр" in d or "киш" in d or "хвост" in d:
		return ["аппетит нестабильный", "стал менее активным", "изменился характер стула", "живот выглядит дискомфортно"]
	if "клещ" in d or "дермат" in d or "алоп" in d or "вш" in d or "гриб" in d or "блох" in d:
		return ["часто расчёсывается", "шерсть стала выглядеть хуже", "беспокоится при прикосновении к коже", "появились участки поредения шерсти"]
	return ["стал менее активным", "аппетит немного снизился", "поведение изменилось", "владелец заметил ухудшение общего состояния"]

func _adapt_method_result(method_name, result_text, severity):
	var text = str(result_text)
	if severity == "лёгкая":
		return text + "\n\nВариант случая: изменения выражены слабо."
	if severity == "тяжёлая":
		return text + "\n\nВариант случая: изменения выражены значительно; требуется внимательная оценка состояния."
	return text + "\n\nВариант случая: изменения умеренной выраженности."

func _generate_case():
	# Берём клиническую основу из базы, а пациента и выраженность симптомов создаём заново.
	# Так правильный диагноз/лечение остаются согласованными с исходным кейсом.
	var base = cases[randi() % cases.size()]
	for attempt in range(12):
		var candidate = cases[randi() % cases.size()]
		var signature = str(candidate.get("species", "")) + "|" + str(candidate.get("disease", ""))
		if not (signature in recent_case_signatures):
			base = candidate
			break
	var c = base.duplicate(true)
	var species_name = _canonical_species(c.get("species", "Пациент"))
	c["species"] = species_name
	c["name"] = _random_name_for_species(species_name)
	c["age"] = _random_age_for_species(species_name)
	c["sex"] = "♀" if randi() % 2 == 0 else "♂"
	var severities = ["лёгкая", "средняя", "тяжёлая"]
	var severity = severities[randi() % severities.size()]
	c["severity"] = severity
	var complaints = c.get("complaints", []).duplicate()
	var extras = _extra_symptoms_for_disease(c.get("disease", ""))
	extras.shuffle()
	if extras.size() > 0:
		complaints.append(str(extras[0]))
	if severity == "тяжёлая" and extras.size() > 1:
		complaints.append(str(extras[1]))
	complaints.shuffle()
	c["complaints"] = complaints
	var methods = c.get("methods", {}).duplicate(true)
	for key in methods.keys():
		methods[key] = _adapt_method_result(str(key), methods[key], severity)
	c["methods"] = methods
	c["generated_note"] = _severity_prefix(severity)
	var sig = species_name + "|" + str(c.get("disease", ""))
	recent_case_signatures.append(sig)
	while recent_case_signatures.size() > 8:
		recent_case_signatures.pop_front()
	return c

func _render():
	_clear_ui()
	var bg = ColorRect.new()
	bg.color = BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	_render_header(bg)
	_render_patient(bg)
	_render_clinic(bg)
	_render_diagnostics(bg)
	_render_results(bg)
	_render_diagnoses(bg)
	_render_treatments(bg)
	_render_footer(bg)

func _render_header(root):
	var header = _panel(root, Rect2(8, 8, 1264, 64), Color("#101d29"), Color("#20364a"), 14)
	_label(header, "🐾  Клиника пушистых животных", Rect2(16, 8, 355, 24), 18, TEXT)
	_label(header, "Учебный ветеринарный симулятор", Rect2(18, 32, 300, 18), 12, MUTED)
	var steps = ["1  Пациент", "2  Диагностика", "3  Диагноз", "4  Лечение"]
	var x = 370
	for i in range(steps.size()):
		var active = stage >= i + 1
		var c = BLUE if active else MUTED.darkened(0.35)
		_label(header, steps[i], Rect2(x, 18, 120, 26), 14, c, HORIZONTAL_ALIGNMENT_CENTER)
		if i < 3:
			var line = ColorRect.new()
			line.color = c.darkened(0.25)
			line.position = Vector2(x + 116, 30)
			line.size = Vector2(16, 2)
			header.add_child(line)
		x += 132
	_label(header, "🪙 %d" % money, Rect2(900, 18, 90, 28), 14, GREEN, HORIZONTAL_ALIGNMENT_CENTER)
	_label(header, "⭐ %d" % stars, Rect2(995, 18, 70, 28), 14, YELLOW, HORIZONTAL_ALIGNMENT_CENTER)
	_label(header, "🏥 %d%%" % int(clinic_rating), Rect2(1070, 18, 90, 28), 13, TEXT, HORIZONTAL_ALIGNMENT_CENTER)

func _render_patient(root):
	var p = _panel(root, Rect2(8, 82, 242, 606), PANEL, LINE, 12)
	_label(p, "ПАЦИЕНТ", Rect2(14, 12, 210, 22), 13, MUTED)
	var avatar = _panel(p, Rect2(14, 44, 214, 104), PANEL_2, Color("#31506a"), 12)
	_label(avatar, str(current_case["icon"]), Rect2(8, 12, 62, 62), 42, TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	_label(avatar, str(current_case["name"]) + "  " + str(current_case["sex"]), Rect2(76, 12, 126, 36), 16, TEXT)
	_label(avatar, str(current_case["species"]), Rect2(76, 46, 126, 22), 13, BLUE)
	_label(avatar, "Возраст: " + str(current_case["age"]), Rect2(76, 68, 126, 28), 12, MUTED)
	_label(p, "Тяжесть: " + str(current_case.get("severity", "обычная")), Rect2(14, 148, 214, 22), 12, YELLOW)

	var sc = ScrollContainer.new()
	sc.position = Vector2(12, 176)
	sc.size = Vector2(218, 370)
	p.add_child(sc)
	var vb = VBoxContainer.new()
	vb.custom_minimum_size = Vector2(198, 0)
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 8)
	sc.add_child(vb)

	_flow_label(vb, "Жалобы", 16, TEXT, 24)
	var complaint_text = ""
	for c in current_case["complaints"]:
		complaint_text += "• " + str(c) + "\n"
	_flow_label(vb, str(current_case.get("generated_note", "")) + "\n" + complaint_text.strip_edges(), 14, TEXT, 125)

	_flow_label(vb, "История приёма", 16, TEXT, 24)
	var hist = "Исследований: %d\nСерия: %d\nСлучаев завершено: %d" % [selected_methods.size(), streak, cases_done]
	_flow_label(vb, hist, 13, MUTED, 70)

	var ref_btn = _button(p, "📚 Справочник", Rect2(16, 555, 208, 36), _open_group_reference, true, false)
	ref_btn.add_theme_font_size_override("font_size", 13)

func _render_clinic(root):
	var p = _panel(root, Rect2(260, 82, 424, 358), PANEL_2, Color("#31506a"), 12)
	_label(p, "Кабинет экзотических животных", Rect2(16, 12, 390, 24), 15, TEXT)
	var wall = ColorRect.new()
	wall.color = Color("#274052")
	wall.position = Vector2(16, 48)
	wall.size = Vector2(392, 200)
	p.add_child(wall)
	var shelf = ColorRect.new()
	shelf.color = Color("#355468")
	shelf.position = Vector2(22, 18)
	shelf.size = Vector2(130, 38)
	wall.add_child(shelf)
	_label(wall, "🧪  🧴  💊", Rect2(28, 17, 120, 28), 20, TEXT)
	var monitor = _panel(wall, Rect2(270, 26, 100, 68), Color("#0b1118"), BLUE.darkened(0.35), 6)
	_label(monitor, "VET\nSCAN", Rect2(8, 12, 84, 42), 13, BLUE, HORIZONTAL_ALIGNMENT_CENTER)
	var table = _panel(wall, Rect2(74, 126, 248, 54), Color("#8296a7"), Color("#b8c7d3"), 8)
	_label(table, str(current_case["icon"]) + "  " + str(current_case["name"]), Rect2(16, 8, 216, 36), 23, Color("#12202d"), HORIZONTAL_ALIGNMENT_CENTER)
	var doctor = _label(wall, "🩺", Rect2(28, 108, 48, 48), 34, TEXT, HORIZONTAL_ALIGNMENT_CENTER)
	doctor.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_label(p, "Текущий этап", Rect2(16, 262, 120, 22), 13, MUTED)
	var stage_text = "Соберите анамнез и начните диагностику."
	if stage == 2:
		stage_text = "Проводите исследования и сопоставляйте результаты."
	elif stage == 3:
		stage_text = "Выберите наиболее вероятный диагноз."
	elif stage == 4 and not case_finished:
		stage_text = "Выберите план лечения для поставленного диагноза."
	elif case_finished:
		stage_text = "Случай завершён. Перейдите к следующему пациенту."
	_label(p, stage_text, Rect2(16, 288, 392, 52), 15, TEXT)


func _get_species_profile(species):
	var profiles = {
	    "Крысы и мыши": "🐭 Крыса декоративная\n\nВид: крыса декоративная\nСемейство: мышиные\nСредняя масса: 250–500 г\nПродолжительность жизни: 2–3 года\nТемпература тела: 37,5–38,5 °C\nЧастота дыхания: 70–150/мин\nЧастота пульса: 250–500 уд/мин\n\nСодержание:\n• просторная клетка\n• социальное содержание\n• без сквозняков\n\nПитание:\n• зерновые смеси\n• белковые добавки\n• овощи\n\nПредрасположенность:\n• респираторные инфекции\n• опухоли\n• болезни зубов\n• паразиты",
	    "Кролики": "🐰 Кролик\n\nТемпература: 38,5–40 °C\nДыхание: 30–60/мин\nПульс: 130–325 уд/мин\nОсобенности:\n• быстрый рост зубов\n• чувствительный ЖКТ\nПредрасположенность:\n• стоматологические болезни\n• энтерит\n• респираторные инфекции",
	    "Морские свинки": "🐹 Морская свинка\n\nТемпература: 37,2–39,5 °C\nДыхание: 40–100/мин\nОсобенности:\n• нуждается в витамине C\n• чувствительные дыхательные пути\nПредрасположенность:\n• пневмония\n• болезни зубов\n• кожные паразиты",
	    "Хомяки": "🐹 Хомяк\n\nТемпература: 36,5–38 °C\nОсобенности:\n• защечные мешки\n• ночная активность\nПредрасположенность:\n• ЖКТ\n• кожа\n• дыхание",
	    "Хорьки": "🦦 Хорёк\n\nТемпература: 37,8–40 °C\nОсобенности:\n• хищное питание\n• чувствительная эндокринная система\nПредрасположенность:\n• сердце\n• гормональные болезни",
	    "Шиншиллы": "🐭 Шиншилла\n\nТемпература: 36–38 °C\nОсобенности:\n• сухая среда\n• песочные купания\nПредрасположенность:\n• зубы\n• ЖКТ\n• кожа"
	}
	return profiles.get(species, "Данные вида отсутствуют")

func _get_method_description(method_name):
	var data = {
		"🔍 Общий осмотр": "Оценка:\n• поведения животного\n• активности\n• упитанности\n• состояния шерсти и кожи\n• слизистых оболочек\n• дыхания\n• внешних признаков заболевания",
		"🩺 Аускультация": "Прослушивание:\n• сердца\n• лёгких\n• дыхательных шумов\n• хрипов\n• нарушений дыхания",
		"🌡 Температура": "Измерение:\n• температуры тела\n• сравнение с нормой вида\n• выявление гипертермии\n• выявление переохлаждения",
		"🔬 Анализ кала": "Определение:\n• паразитов\n• простейших\n• нарушений пищеварения\n• воспалительных признаков",
		"🩸 Анализ крови": "Оценка:\n• воспаления\n• анемии\n• инфекции\n• общего состояния организма",
		"🩻 Рентген": "Исследование:\n• лёгких\n• сердца\n• ЖКТ\n• костей\n• зубов"
	}
	return data.get(method_name, "Метод исследования пациента.")


func _render_diagnostics(root):
	var p = _panel(root, Rect2(694, 82, 274, 358), PANEL, LINE, 12)
	_label(p, "МЕТОДЫ ОБСЛЕДОВАНИЯ", Rect2(14, 12, 246, 22), 13, MUTED)

	var sc = ScrollContainer.new()
	sc.position = Vector2(12, 42)
	sc.size = Vector2(250, 304)
	p.add_child(sc)

	var vb = VBoxContainer.new()
	vb.custom_minimum_size = Vector2(228, 0)
	vb.add_theme_constant_override("separation", 10)
	sc.add_child(vb)

	var methods = ["🔍 Общий осмотр", "🩺 Аускультация", "🌡 Температура", "🔬 Анализ кала", "🩸 Анализ крови", "🩻 Рентген"]

	for method_name in methods:
		var card = _panel(vb, Rect2(0,0,228,210), CARD, LINE, 8)
		card.custom_minimum_size = Vector2(228,210)

		_label(card, method_name, Rect2(8,8,210,26), 14, TEXT)

		var desc = Label.new()
		desc.text = _get_method_description(method_name)
		desc.position = Vector2(8,38)
		desc.size = Vector2(210,120)
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		desc.add_theme_font_size_override("font_size", 11)
		desc.add_theme_color_override("font_color", MUTED)
		card.add_child(desc)

		var b = Button.new()
		b.text = "▶ Провести"
		b.position = Vector2(8,165)
		b.size = Vector2(210,32)
		b.disabled = method_name in selected_methods or case_finished
		b.pressed.connect(_run_method.bind(method_name))
		card.add_child(b)

func _render_results(root):
	var p = _panel(root, Rect2(978, 82, 294, 358), PANEL, LINE, 12)
	_label(p, "РЕЗУЛЬТАТ ИССЛЕДОВАНИЯ", Rect2(14, 12, 266, 22), 13, MUTED)
	var rr = _rich(p, Rect2(14, 44, 266, 214))
	var status_color = "#2da8ff"
	var title = "Диагностика"
	if case_finished:
		status_color = "#37d67a" if selected_diagnosis == current_case["disease"] and selected_treatment == current_case["treatment"] else "#ffc857"
		title = "Итог случая"
	rr.text = "[color=%s][font_size=20][b]%s[/b][/font_size][/color]\n\n%s" % [status_color, title, current_result]


func _render_diagnoses(root):
	var p = _panel(root, Rect2(260, 450, 350, 238), PANEL, LINE, 12)
	_label(p, "ВЫБЕРИТЕ ДИАГНОЗ", Rect2(14, 12, 170, 22), 13, MUTED)
	var enabled = selected_methods.size() >= 2 and not case_finished
	if selected_methods.size() < 2:
		_label(p, "Выполните ещё %d исслед." % (2 - selected_methods.size()), Rect2(176, 10, 160, 22), 12, YELLOW, HORIZONTAL_ALIGNMENT_RIGHT)
	var sc = ScrollContainer.new()
	sc.position = Vector2(12, 42)
	sc.size = Vector2(326, 184)
	p.add_child(sc)
	var vb = VBoxContainer.new()
	vb.custom_minimum_size = Vector2(304, 0)
	vb.add_theme_constant_override("separation", 6)
	sc.add_child(vb)
	for d in diagnosis_options:
		var is_sel = selected_diagnosis == str(d)
		var b = _button(vb, ("◉ " if is_sel else "○ ") + str(d), Rect2(0, 0, 304, 52), _choose_diagnosis.bind(str(d)), enabled, is_sel)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(304, 52)

func _render_treatments(root):
	var p = _panel(root, Rect2(620, 450, 652, 238), PANEL, LINE, 12)
	_label(p, "ВЫБЕРИТЕ ЛЕЧЕНИЕ", Rect2(14, 12, 310, 22), 13, MUTED)
	var can_treat = selected_diagnosis != "" and not case_finished
	var sc = ScrollContainer.new()
	sc.position = Vector2(12, 42)
	sc.size = Vector2(628, 148)
	p.add_child(sc)
	var grid = GridContainer.new()
	grid.columns = 2
	grid.custom_minimum_size = Vector2(608, 0)
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 8)
	sc.add_child(grid)
	for i in range(treatment_options.size()):
		var t = str(treatment_options[i])
		var is_sel = selected_treatment == t
		var b = _button(grid, ("◉ " if is_sel else "○ ") + t, Rect2(0, 0, 298, 86), _choose_treatment.bind(t), can_treat, is_sel)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(298, 86)
		b.text_overrun_behavior = TextServer.OVERRUN_NO_TRIMMING
	if selected_treatment != "" and not case_finished:
		_button(p, "✓ Подтвердить план лечения", Rect2(328, 198, 310, 32), _finish_case, true, true)
	elif case_finished:
		_button(p, "Следующий пациент →", Rect2(328, 198, 310, 32), new_case, true, true)

func _render_footer(root):
	_label(root, "Учебный симулятор: справочник грызунов адаптирован по П. К. Бергхоф (2006); кейсы кошек и собак — учебные примеры. Не использовать для реального лечения.", Rect2(14, 694, 1252, 22), 10, Color("#7890a2"), HORIZONTAL_ALIGNMENT_CENTER)

func _run_method(method_name):
	if case_finished:
		return
	if not (method_name in selected_methods):
		selected_methods.append(method_name)
		money = max(0, money - 75)
	var default_results = {
		"🔍 Общий осмотр": "Пациент: %s\n\nАктивность: снижена\nШерсть: тусклая, взъерошенная\nКожа: без повреждений\nСлизистые: розовые\nДыхание: учащённое\n\nПолучено: признаки, требующие дополнительной диагностики." % str(current_case.get("name", "животное")),
		"🩺 Аускультация": "Сердце: ритм правильный\nЛёгкие: дыхание жёсткое\nХрипы: не обнаружены\n\nПолучено: данные дыхательной системы.",
		"🌡 Температура": "Температура: 38,2 °C\nНорма для вида: соответствует виду\nЗаключение: в пределах нормы.",
		"🔬 Анализ кала": "Паразиты: не обнаружены\nПризнаки воспаления: отсутствуют.",
		"🩸 Анализ крови": "Воспаление: нет выраженных изменений\nОбщее состояние: удовлетворительное.",
		"🩻 Рентген": "Лёгкие: без затемнений\nЗубы: оценка корней и длины зубов\nПолучено: данные для диагностики."
	}
	var method_results = current_case.get("methods", {})
	var result_text = method_results.get(method_name, default_results.get(method_name, "Получены данные обследования."))
	# Исследования открывают только подходящие признаки болезней
	var low_result = str(result_text).to_lower()
	if method_name == "🩻 Рентген" and ("зуб" in low_result or "резц" in low_result):
		diagnostic_flags["teeth_problem"] = true
	if method_name == "🔍 Общий осмотр":
		if "шерст" in low_result or "кож" in low_result:
			diagnostic_flags["skin_problem"] = true
		if "зуб" in low_result or "резц" in low_result:
			diagnostic_flags["teeth_problem"] = true
	if method_name == "🩺 Аускультация" and ("дых" in low_result or "хрип" in low_result):
		diagnostic_flags["respiratory_problem"] = true
	current_result = "[b]📋 %s[/b]\n\nРезультат исследования:\n%s" % [method_name, str(result_text)]
	stage = 3 if selected_methods.size() >= 2 else 2
	_save()
	_render()

func _choose_diagnosis(diagnosis):
	if selected_methods.size() < 2 or case_finished:
		return
	selected_diagnosis = diagnosis
	selected_treatment = ""
	stage = 4
	current_result = "Вы выбрали диагноз: [b]%s[/b].\n\nТеперь выберите план лечения." % diagnosis
	_save()
	_render()

func _choose_treatment(treatment):
	if selected_diagnosis == "" or case_finished:
		return
	selected_treatment = treatment
	current_result = "Диагноз: [b]%s[/b]\nПлан: [b]%s[/b]\n\nНажмите «Подтвердить план лечения»." % [selected_diagnosis, treatment]
	_save()
	_render()

func _finish_case():
	if selected_treatment == "" or case_finished:
		return
	case_finished = true
	cases_done += 1
	day_patients += 1
	var diag_ok = selected_diagnosis == str(current_case["disease"])
	if diag_ok:
		day_correct += 1
	day_researches += selected_methods.size()
	clinic_rating = clamp(float(score) / max(1, cases_done + 1) * 10.0, 0.0, 100.0)
	var treat_ok = selected_treatment == str(current_case["treatment"])
	var reward = 0
	if diag_ok:
		reward += 250
		score += 2
	if treat_ok:
		reward += 250
		score += 2
	if diag_ok and treat_ok:
		streak += 1
		reward += 150
		score += 1
	else:
		streak = 0
	money += reward
	stars += 1
	var diag_text = "✅ Верно" if diag_ok else "❌ Ошибка"
	var treat_text = "✅ Верно" if treat_ok else "❌ Ошибка"
	current_result = "[font_size=20][b]ИТОГ СЛУЧАЯ[/b][/font_size]\n\n" + \
	"Пациент: %s\n\n" % str(current_case["name"]) + \
	"Диагноз: %s\n" % diag_text + \
	"Исследований сделано: 🔬 %d\n\n" % selected_methods.size() + \
	"Награда: 🪙 +%d монет\n⭐ +1 звезда\n\n" % reward + \
	"Рейтинг клиники: 🏥 %.0f%%\n\n" % clinic_rating + \
	"СТАТИСТИКА ДНЯ (%d/5 пациентов)\n" % day_patients + \
	"Верных диагнозов: %d\nИсследований: %d\nОбщий баланс: 🪙 %d" % [day_correct, day_researches, money]
	_finish_day()
	_save()
	_render()


func _free_children(node):
	if node == null:
		return
	for c in node.get_children():
		node.remove_child(c)
		c.queue_free()

func _bb_list(items):
	var lines = []
	for item in items:
		lines.append("• " + str(item))
	return "\n".join(lines)

func _show_reference():
	reference_db = {}
	var f = FileAccess.open("res://data/reference_guide.json", FileAccess.READ)
	if f:
		var parsed = JSON.parse_string(f.get_as_text())
		if typeof(parsed) == TYPE_DICTIONARY:
			reference_db = parsed

	var overlay = ColorRect.new()
	overlay.color = Color(0.02, 0.05, 0.08, 0.95)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(overlay)

	var p = _panel(overlay, Rect2(40, 20, 1200, 700), Color("#132130"), Color("#41657d"), 14)
	_label(p, "📚 ОБШИРНЫЙ СПРАВОЧНИК МЕЛКИХ МЛЕКОПИТАЮЩИХ", Rect2(25, 15, 780, 35), 24, TEXT)
	_button(p, "Закрыть", Rect2(1030, 15, 120, 36), overlay.queue_free, true, false)

	var left = _panel(p, Rect2(20, 70, 260, 600), Color("#182b3b"), Color("#31506a"), 12)
	var middle = _panel(p, Rect2(300, 70, 330, 600), Color("#182b3b"), Color("#31506a"), 12)
	var right = _panel(p, Rect2(650, 70, 520, 600), Color("#182b3b"), Color("#31506a"), 12)

	_label(left, "🐾 Виды животных", Rect2(15, 15, 220, 30), 20, TEXT)
	var y = 55
	for species in reference_db.get("species", {}).keys():
		_button(left, species, Rect2(15, y, 220, 38), _show_reference_species.bind(str(species), middle, right), true, false)
		y += 45

	_label(middle, "🌳 Разделы и болезни", Rect2(15, 15, 280, 30), 20, TEXT)
	_label(right, "📖 Карточка", Rect2(15, 15, 400, 30), 20, TEXT)

# Large touch-friendly scrollbar and up/down controls for Android.
func _make_scroll_easy(scroll: ScrollContainer) -> void:
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	# Прокрутка остаётся доступна через кнопки ▲ и ▼.
	var parent = scroll.get_parent()
	var x = scroll.position.x + scroll.size.x + 5
	var top = scroll.position.y
	var height = scroll.size.y
	for label_text in ["▲", "▼"]:
		var b = Button.new()
		b.text = label_text
		b.position = Vector2(x, top if label_text == "▲" else top + height - 66)
		b.size = Vector2(58, 60)
		b.add_theme_font_size_override("font_size", 29)
		b.tooltip_text = "Прокрутить вверх" if label_text == "▲" else "Прокрутить вниз"
		parent.add_child(b)
		b.pressed.connect(_scroll_by_amount.bind(scroll, -280 if label_text == "▲" else 280))
		b.name = "ScrollUpButton" if label_text == "▲" else "ScrollDownButton"

func _scroll_by_amount(scroll: ScrollContainer, amount: int) -> void:
	if is_instance_valid(scroll):
		scroll.scroll_vertical = maxi(0, scroll.scroll_vertical + amount)

func _reference_scroll_content(panel, content_name):
	for button_name in ["ScrollUpButton", "ScrollDownButton"]:
		var old_button = panel.get_node_or_null(button_name)
		if old_button:
			panel.remove_child(old_button)
			old_button.queue_free()
	var old = panel.get_node_or_null(content_name + "Scroll")
	if old:
		# Remove the previous species UI immediately. queue_free() alone is deferred
		# until the end of the frame and caused old species sections to remain visible.
		panel.remove_child(old)
		old.queue_free()
	var scroll = ScrollContainer.new()
	scroll.name = content_name + "Scroll"
	scroll.position = Vector2(10, 50)
	scroll.size = Vector2(panel.size.x - 90, panel.size.y - 60)
	panel.add_child(scroll)
	_make_scroll_easy(scroll)
	var content = Control.new()
	content.name = content_name
	content.custom_minimum_size = Vector2(scroll.size.x - 18, 1200)
	scroll.add_child(content)
	return content

func _show_reference_species(species, middle, right):
	if not reference_db.has("species") or not reference_db["species"].has(species):
		return

	# Completely clear both dynamic columns before drawing the newly selected species.
	# This prevents controls and callbacks from the previous species from staying on screen.
	for child in middle.get_children():
		if child.name.ends_with("Scroll") or child.name.begins_with("ScrollUpButton") or child.name.begins_with("ScrollDownButton"):
			middle.remove_child(child)
			child.queue_free()
	for child in right.get_children():
		if child.name.ends_with("Scroll") or child.name.begins_with("ScrollUpButton") or child.name.begins_with("ScrollDownButton"):
			right.remove_child(child)
			child.queue_free()

	var middle_content = _reference_scroll_content(middle, "TreeContent")
	var data = reference_db["species"][species]
	var y = 5
	_button(middle_content, "📋 О животном и физиология", Rect2(5, y, 205, 38), _show_reference_card.bind("📋 О животном и физиология", data.get("physiology", {}).duplicate(true), right), true, false)
	y += 48
	for organ in data.get("tree", {}).keys():
		_label(middle_content, organ, Rect2(5, y, 205, 30), 17, TEXT)
		y += 34
		for disease in data["tree"][organ].keys():
			_button(middle_content, "  └ " + disease, Rect2(5, y, 205, 34), _show_reference_card.bind(str(disease), data["tree"][organ][disease].duplicate(true), right), true, false)
			y += 40
	middle_content.custom_minimum_size.y = max(y + 20, 540)
	_show_reference_card("📋 О животном и физиология", data.get("physiology", {}), right)

func _show_reference_card(title, data, right):
	for button_name in ["ScrollUpButton", "ScrollDownButton"]:
		var old_button = right.get_node_or_null(button_name)
		if old_button:
			right.remove_child(old_button)
			old_button.queue_free()
	var old = right.get_node_or_null("CardContentScroll")
	if old:
		right.remove_child(old)
		old.queue_free()

	var scroll = ScrollContainer.new()
	scroll.name = "CardContentScroll"
	scroll.position = Vector2(12, 50)
	scroll.size = Vector2(right.size.x - 92, right.size.y - 62)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right.add_child(scroll)
	_make_scroll_easy(scroll)

	var card = RichTextLabel.new()
	card.name = "CardText"
	card.bbcode_enabled = true
	card.fit_content = true
	card.scroll_active = false
	card.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	card.custom_minimum_size = Vector2(scroll.size.x - 24, 0)
	card.add_theme_font_size_override("normal_font_size", 16)
	card.add_theme_font_size_override("bold_font_size", 17)
	card.add_theme_color_override("default_color", TEXT)
	card.add_theme_constant_override("line_separation", 6)
	scroll.add_child(card)

	var text = "[font_size=23][b]%s[/b][/font_size]\n\n" % str(title)
	for key in data.keys():
		if str(key).strip_edges().to_lower() in ["примечание", "примечания", "note", "notes"]:
			continue
		text += "[font_size=17][b]%s:[/b][/font_size]\n" % str(key)
		var value = data[key]
		if typeof(value) == TYPE_ARRAY:
			for item in value:
				text += "• %s\n" % str(item)
		else:
			text += "%s\n" % str(value)
		text += "\n"
	card.text = text


func _ref_select_species(species):
	var species_source = reference_db
	if reference_db.has("species") and typeof(reference_db["species"]) == TYPE_DICTIONARY:
		species_source = reference_db["species"]
	if not species_source.has(species):
		return
	_free_children(ref_organs_box)
	_free_children(ref_diseases_box)
	ref_card_title.text = species
	ref_card.text = "[font_size=20][b]%s[/b][/font_size]\n\nВыберите орган или систему, затем болезнь." % species

	var organs = species_source[species].keys()
	organs.sort()
	for organ in organs:
		var b = _button(ref_organs_box, "🩺 " + str(organ), Rect2(0, 0, 284, 42), _ref_select_organ.bind(str(species), str(organ)), true, false)
		b.custom_minimum_size = Vector2(284, 42)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.add_theme_font_size_override("font_size", 14)

	if organs.size() > 0:
		_ref_select_organ(species, str(organs[0]))

func _ref_select_organ(species, organ):
	var species_source = reference_db
	if reference_db.has("species") and typeof(reference_db["species"]) == TYPE_DICTIONARY:
		species_source = reference_db["species"]
	if not species_source.has(species):
		return
	var species_data = species_source[species]
	if not species_data.has(organ):
		return
	_free_children(ref_diseases_box)
	var disease_map = species_data[organ]
	ref_card_title.text = "%s • %s" % [species, organ]

	var disease_keys = disease_map.keys()
	disease_keys.sort()
	if disease_keys.size() == 0:
		ref_card.text = "[font_size=20][b]%s[/b][/font_size]\n[color=#9fb0bf]%s • %s[/color]\n\nВ этом разделе карточки болезней пока не добавлены." % [organ, species, organ]
		return

	for disease in disease_keys:
		var b = _button(ref_diseases_box, "• " + str(disease), Rect2(0, 0, 284, 46), _ref_select_disease.bind(str(species), str(organ), str(disease)), true, false)
		b.custom_minimum_size = Vector2(284, 46)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.add_theme_font_size_override("font_size", 14)

	_ref_select_disease(species, organ, str(disease_keys[0]))

func _ref_select_disease(species, organ, disease):
	if not reference_db.has("species"):
		return
	var entry = reference_db["species"][species]["tree"][organ][disease]
	ref_card_title.text = "%s / %s / %s" % [species, organ, disease]
	var text = "[font_size=24][b]%s[/b][/font_size]\n\n" % disease
	text += "[b]Симптомы:[/b]\n%s\n\n" % _bb_list(entry.get("Симптомы", entry.get("symptoms", [])))
	text += "[b]Диагностика:[/b]\n%s\n\n" % _bb_list(entry.get("Диагностика", entry.get("diagnostics", [])))
	text += "[b]Результаты исследований:[/b]\n%s\n\n" % _bb_list(entry.get("Результаты", entry.get("results", [])))
	text += "[b]Лечение:[/b]\n%s\n\n" % _bb_list(entry.get("Лечение", entry.get("treatment", [])))
	text += "[b]Профилактика:[/b]\n%s" % _bb_list(entry.get("Профилактика", entry.get("prevention", [])))
	ref_card.text = text

