#!/bin/sh
set -e
cd "$(dirname "$0")"
mkdir -p build/web
godot --headless --path . --export-release Web build/web/index.html
printf 'Web export ready in build/web\n'
